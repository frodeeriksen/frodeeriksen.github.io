-- Enable Sample Data Module.
UPDATE "#__extensions" SET "enabled" = '1' WHERE "name" = 'mod_sampledata';
